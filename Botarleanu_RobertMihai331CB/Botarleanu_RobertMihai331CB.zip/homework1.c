#include "homework1.h"

int num_threads;
int resolution;

void initialize(image *im) {

}

void render(image *im) {

}

void writeData(const char * fileName, image *img) {

}


#!/bin/sh
./homework '../highres.pnm' 'out/highres.pnm' $1 $2
